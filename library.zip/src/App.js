import React from 'react';
import './App.css';

const projectList = [
    {
        name: "Практика Запятых",
        link: "./all-projects/commas/index.html",
        type: "Проект"
    },

    {
        name: "Conditionals. Практика Всех Видов",
        link: "./all-projects/conditionals/index.html",
        type: "Проект"
    },
        
    {
        name: "Conditionals Zero. ",
        link: "./all-projects/conditionals-zero/index.html",
        type: "Проект"
    },
    
    {
        name: "Conditionals Second. Практика",
        link: "./all-projects/conditionals-second/index.html",
        type: "Проект"
    },
    
    {
        name: "HTML. Очистка от Тегов",
        link: "./all-projects/html-stripper/index.html",
        type: "Проект"
    },

    {
        name: "Идиоматические Выражения",
        link: "./all-projects/idiomatic-expressions/index.html",
        type: "Проект"
    },
    
    {
        name: "Строки. Разбивка Текста",
        link: "./all-projects/line-breaker/index.html",
        type: "Проект"
    },

    {
        name: "Mind Maps. Список",
        link: "./all-projects/mind-maps-list/index.html",
        type: "Проект"
    },
    
    {
        name: "Дневничок",
        link: "./all-projects/my-diary/index.html",
        type: "Проект"
    },
    
    {
        name: "Заметочки",
        link: "./all-projects/notes/index.html",
        type: "Проект"
    },
    
    {
        name: "Present Perfect. Практика",
        link: "./all-projects/present-perfect-practice/index.html",
        type: "Проект"
    },
    
    {
        name: "Читалка",
        link: "./all-projects/reading-app/index.html",
        type: "Проект"
    },
    
    {
        name: "Regex. Практика",
        link: "./all-projects/regex-quiz/index.html",
        type: "Проект"
    },
    
    {
        name: "Практика Русских Вопросов",
        link: "./all-projects/russian-questions/index.html",
        type: "Проект"
    },
    
    {
        name: "График. Расчёт 2/2",
        link: "./all-projects/schedule/index.html",
        type: "Проект"
    },
    
    {
        name: "Список Дел",
        link: "./all-projects/todo-app/index.html",
        type: "Проект"
    },
    
    {
        name: "Города. Поиск Ближайших Городов",
        link: "./all-projects/towns/index.html",
        type: "Проект"
    },
    
    {
        name: "Города. Игра",
        link: "./all-projects/towns-game/index.html",
        type: "Проект"
    },
    
    {
        name: "Проценты. От 20% и Дальше",
        link: "./all-projects/twenty-percents/index.html",
        type: "Проект"
    },
    
    {
        name: "Погода. Обзор и Прогнозы",
        link: "./all-projects/weather-finder/index.html",
        type: "Проект"
    },
    
    {
        name: "Дни",
        link: "./all-projects/days/index.html",
        type: "Проект"
    },
    
    {
        name: "Future Perfect",
        link: "./all-projects/future-perfect-practice/index.html",
        type: "Проект"
    },
    
    {
        name: "Reminder",
        link: "./all-projects/reminder/index.html",
        type: "Проект"
    },
    
    {
        name: "Random Name Generator",
        link: "./all-projects/random-name-generator/index.html",
        type: "Проект"
    },
    
    {
        name: "Health Timer",
        link: "./all-projects/health-timer/index.html",
        type: "Проект"
    },
    
    // Добавьте в этот список все свои проекты
].sort((a, b) => a.name.localeCompare(b.name));

const bookList = [
    {
        name: "Копирайтинг",
        link: "./all-books/copywriting.pdf",
        type: "Книга"
    },

    {
        name: "GPT",
        link: "./all-books/GPT.pdf",
        type: "Книга"
    },
    
    {
        name: "Кант",
        link: "./all-books/kant.pdf",
        type: "Книга"
    },
    
    {
        name: "Маркетинговые методы",
        link: "./all-books/marketing.pdf",
        type: "Книга"
    },

    {
        name: "Богатый Папа и Бедный Папа",
        link: "./all-books/rich-poor.pdf",
        type: "Книга"
    },

    {
        name: "CSS",
        link: "./all-books/secrets.pdf",
        type: "Книга"
    },
    
    {
        name: "Telegram-WhatsApp",
        link: "./all-books/telegram-whatsapp.pdf",
        type: "Книга"
    },
    
    {
        name: "UX",
        link: "./all-books/ux.pdf",
        type: "Книга"
    },

    {
        name: "CSS Дукетт",
        link: "./all-books/duckett.pdf",
        type: "Книга"
    },
    // Добавьте в этот список все свои книги
].sort((a, b) => a.name.localeCompare(b.name));

function splitIntoChunks(array, chunkSize) {
    let chunks = [];
    for (let i = 0; i < array.length; i += chunkSize) {
        chunks.push(array.slice(i, i + chunkSize));
    }
    return chunks;
}

function App() {
    const projectChunks = splitIntoChunks(projectList, 6);
    const bookChunks = splitIntoChunks(bookList, 3);

    const handleOnClick = (event, link) => {
        event.preventDefault();
        const randomX = Math.floor(Math.random() * 1000) - 500;  // Generate a random number between -500 and 500
        const randomY = Math.floor(Math.random() * 1000) - 500;  // Generate a random number between -500 and 500
        const flyAwayAnimation = `flyAway ${randomX}px ${randomY}px`;
        event.target.style.animationName = flyAwayAnimation;
        event.target.classList.add('flyAway');
        setTimeout(() => {
            window.open(link, '_blank');
            event.target.classList.remove('flyAway');
        }, 1000);  // 1000 is the duration of the animation in milliseconds
    }


    return (
      <div className="app">
          <div className="projects-container">
              <h1>Проекты</h1>
              <div className="columns-container">
                  {projectChunks.map((chunk, index) => (
                      <div key={index} className="column">
                          {chunk.map((project, index) => (
                              <p key={index}>
                                  <a 
                                      href={project.link} 
                                      target="_blank" 
                                      rel="noopener noreferrer" 
                                      onClick={(event) => handleOnClick(event, project.link)}
                                  >
                                      {project.name}
                                  </a>
                              </p>
                          ))}
                      </div>
                  ))}
              </div>
          </div>
          <div className="books-container">
              <h1>Книги</h1>
              <div className="columns-container">
                  {bookChunks.map((chunk, index) => (
                      <div key={index} className="column">
                          {chunk.map((book, index) => (
                              <p key={index}>
                                  <a 
                                      href={book.link} 
                                      target="_blank" 
                                      rel="noopener noreferrer" 
                                      onClick={(event) => handleOnClick(event, book.link)}
                                  >
                                      {book.name}
                                  </a>
                              </p>
                          ))}
                      </div>
                  ))}
              </div>
          </div>
      </div>
    );
}

export default App;
